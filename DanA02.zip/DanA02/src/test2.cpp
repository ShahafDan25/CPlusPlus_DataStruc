//============================================================================
// Name        : DanA02.cpp
// Author      : ShahafDan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main()
{
	cout << " This is assignment 0.2 of our class (CS20). Join the Chess Club !!!!" << endl;
}
